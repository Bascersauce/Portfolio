import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class Main {
	
	public static final double LASER_SPEED = 0.2; //(mm/s)

	public static void main(String[] args) {

	
		
		JFrame frame = new JFrame();

		
		String input = JOptionPane.showInputDialog(frame,"Enter Full File Location: "); //Input for file location
		String fileName = input.replace("/", "//"); //Adding second backslash so Java can read the location
		
		
		String line = null;
		int fileLength = 0;
		double totalDistance = 0;
		double tempDistance = 0;
		ArrayList<String> codeLines = new ArrayList<String>(); //List of lines containing "G1 " at start


		

		try {

			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			
			//Reads through entire file
			while ((line = bufferedReader.readLine()) != null) {
				fileLength++; //Counts number of lines in file
				System.out.println(line); //Prints out entire file

				if (line.startsWith("G1 ")) {

					codeLines.add(line); //These lines added will later be dissected for X and Y values

				}

				if (line.startsWith("BEAMOFF")) {

					tempDistance = getDistance(codeLines); //Finds distance traveled for entire shape 
					System.out.println(tempDistance);
					codeLines.clear(); //Clears array in preparation for a new shape (set of cuts starting at a different location)
					totalDistance += tempDistance; //Adds that distance to the running total

				}

			}
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
		}

		System.out.println("\nFile length: " + fileLength);

		System.out.println("\nTotal distance travelled: " + totalDistance);

		
		
		JOptionPane.showMessageDialog ( 
				null, "Estimated Time: " + Math.round(totalDistance*(1/LASER_SPEED)/60.0) + " (min)", "Results", 
				JOptionPane.PLAIN_MESSAGE); 
				System.exit ( 0 );
		
		
	}

	public static double distance(double x1, double x2, double y1, double y2) {
		return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow(y2 - y1, 2)); //Distance between two points
	}

	public static double getDistance(ArrayList<String> list) {

		double distance = 0;
		ArrayList<Double> xPosition = new ArrayList<Double>();
		ArrayList<Double> yPosition = new ArrayList<Double>();

		for (int i = 0; i < list.size(); i++) {

			//Uses constant points in the code to find the X and Y values
			int index1 = list.get(i).indexOf('X');
			int index2 = list.get(i).indexOf('Y');
			int index3 = list.get(i).indexOf('F');
			xPosition.add(Double.parseDouble(list.get(i).substring(index1 + 1, index2 - 2))); //Creating X value
			yPosition.add(Double.parseDouble(list.get(i).substring(index2 + 1, index3 - 2))); //Creating Y value

		}

		for (int k = 0; k < xPosition.size() - 1; k++) {

			double temp = distance(xPosition.get(k), xPosition.get(k + 1), yPosition.get(k), yPosition.get(k + 1)); //Calls distance method for (x1, y1) to (x2, y2))
			distance += temp; //Adds distance to running total for this specific shape

		}

		for (int j = 0; j < xPosition.size(); j++) {
			System.out.println("x = " + xPosition.get(j) + ", y = " + yPosition.get(j));
		}

		return distance; //Returns total distance traveled for this specific shape
	}

}
