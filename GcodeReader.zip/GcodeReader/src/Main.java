/* 
 * Project: Oxford Laser Job Time Estimator
 * Author: 	Gabriel Maguire
 * Date: 	1/8/2018
 * 
 * Description:
 * 
 * This program was created to be used on the Micro Machining System Oxford Laser in Glennan 507B (CWRU Campus).
 * The laser this program is intended to be used on does not have a built-in job time estimator. Job times on
 * this laser can take upwards on 24 hours which means it is important to be able to estimate your job completion
 * time before starting.
 * 
 * The laser jobs are programmed in G-code. This program reads through the G-code file (.pgm) to collect the entire
 * length of commands, and uses that and user input to compute the estimated job time.
 * 
 * This program is not meant to give a perfect representation of the job time, rather it gives a good estimate (within ~10%),
 * as it only covers the most common types of commands in the G-code language.
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

public class Main {

	public static File file;
	
	public void createGUI() {

		JFrame frame = new JFrame();

		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setMultiSelectionEnabled(false);
		fileChooser.setCurrentDirectory(new File("C:\\LabUsers"));

		JLabel label3 = new JLabel("Completion Time: ");
		JLabel output = new JLabel("");
		JLabel speedCutL = new JLabel("Enter Cut Speed (mm/s): ");
		JLabel numCutL = new JLabel("Enter # of Cut Passes: ");
		JLabel speedEtchL = new JLabel("Enter Etch Speed (mm/s): ");
		JLabel numEtchL = new JLabel("Enter # of Etch Passes: ");

		JTextField speedCutT = new JTextField();
		JTextField numCutT = new JTextField();
		JTextField speedEtchT = new JTextField();
		JTextField numEtchT = new JTextField();
		
		JButton button1 = new JButton("Select File");
		
		button1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				fileChooser.showDialog(frame, "Select File");
				file = fileChooser.getSelectedFile();
				System.out.println(file);
			}
		});

		JButton button2 = new JButton("Compute");
		button2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				double sC = Double.parseDouble(speedCutT.getText());
				int nC = Integer.parseInt(numCutT.getText());
				double sE = Double.parseDouble(speedEtchT.getText());
				int nE = Integer.parseInt(numEtchT.getText());
				
				System.out.println(sC + ", " + nC + ", " + sE + ", " + nE);
				
				int time = run(sC, nC, sE, nE);
				int hours = time / 60;
				int minutes = time % 60;
				String textOutput = Integer.toString(hours) + " hr(s) and " + Integer.toString(minutes) + " min(s)";
				output.setText(textOutput);
			}
		});

		JPanel inputControls = new JPanel(new BorderLayout(5, 5));

		JPanel inputControlsLabels = new JPanel(new GridLayout(0, 1, 3, 3));
		JPanel inputControlsFields = new JPanel(new GridLayout(0, 1, 3, 3));
		inputControls.add(inputControlsLabels, BorderLayout.WEST);
		inputControls.add(inputControlsFields, BorderLayout.CENTER);

		
		inputControlsLabels.add(speedCutL);
		inputControlsLabels.add(numCutL);
		inputControlsLabels.add(speedEtchL);
		inputControlsLabels.add(numEtchL);
		inputControlsLabels.add(label3);
		
		
		inputControlsFields.add(speedCutT);
		inputControlsFields.add(numCutT);
		inputControlsFields.add(speedEtchT);
		inputControlsFields.add(numEtchT);
		inputControlsFields.add(output);
		

		JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));

		controls.add(button1);
		controls.add(button2);

		JPanel gui = new JPanel(new BorderLayout(10, 10));
		gui.setBorder(new TitledBorder("Time Estimation"));
		gui.add(inputControls, BorderLayout.CENTER);
		gui.add(controls, BorderLayout.SOUTH);

		frame.setContentPane(gui);
		frame.getContentPane().setBackground(new Color(216,191,216));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 200);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}

	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Main().createGUI();
			}
		});

	}

	public int run(double cutSpeed, int cutPasses, double etchSpeed, int etchPasses) {

		String line = null;
		
		double totalDistanceCut = 0;
		double totalDistanceEtch = 0;
		double tempDistanceCut = 0;
		double tempDistanceEtch = 0;
		
		// List of lines staring with "G1 " for both cutting and etching
		ArrayList<String> codeLinesCut = new ArrayList<String>();
		ArrayList<String> codeLinesEtch = new ArrayList<String>();

		try {

			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			// Reads through entire file
			while ((line = bufferedReader.readLine()) != null) {

				// The last word determines cutting vs etching
				String lastWord = line.substring(line.lastIndexOf(" ") + 1);
				
				// Simple straight line command (most common)
				if (line.startsWith("G1 ")) {			
					
					if (lastWord.equals("$CUTSPEED")) {
						codeLinesCut.add(line); // These lines added will later be dissected for X and Y values
					} else {
						codeLinesEtch.add(line);
					}
				}

				// Circular command
				else if (line.startsWith("G2 ")) {
					
					if (lastWord.equals("$CUTSPEED")) {
						totalDistanceCut += getCircleDistance(line); // Adds distance traveled for circular cut
					} else {
						totalDistanceEtch += getCircleDistance(line);
					}
				}

				// BEAMOFF denotes the completion of a shape
				else if (line.startsWith("BEAMOFF")) {
					
					tempDistanceCut = getDistance(codeLinesCut); // Finds distance traveled for entire shape
					codeLinesCut.clear(); // Clears array in preparation for a new shape (set of cuts starting at a
										// different location)
					totalDistanceCut += tempDistanceCut; // Adds that distance to the running total
					
					
					tempDistanceEtch = getDistance(codeLinesEtch);
					codeLinesEtch.clear();
					totalDistanceEtch += tempDistanceEtch;
				}

			}
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + file + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + file + "'");
		}

		int cutTime = 0;
		int etchTime = 0;
		
		if (cutSpeed > 0 && cutPasses > 0) {
			cutTime = (int) Math.round(totalDistanceCut / cutSpeed / 60.0 * cutPasses);
			System.out.println("Total Distance Cut: " + totalDistanceCut);
			System.out.println(cutTime);
		}
		if (etchSpeed > 0 && etchPasses > 0) {
			etchTime = (int) Math.round(totalDistanceEtch / etchSpeed / 60.0 * etchPasses);
			System.out.println("Total Distance Etch: " + totalDistanceEtch);
			System.out.println(etchTime);
		}
		int totalTime = cutTime + etchTime;
		System.out.println(totalTime);

		return totalTime;
	}

	public static double distance(double x1, double x2, double y1, double y2) {
		return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow(y2 - y1, 2)); // Distance between two points
	}

	public static double getCircleDistance(String input) {
		// Uses constant characters in the code to find the radius
		int index1 = input.indexOf('I');
		int index2 = input.indexOf('J');
		double r = Double.parseDouble(input.substring(index1 + 1, index2 - 2));
		return r * 2.0 * Math.PI;
	}

	public static double getDistance(ArrayList<String> list) {

		// Collect X and Y data from previously collected strings
		double distance = 0;
		ArrayList<Double> xPosition = new ArrayList<Double>();
		ArrayList<Double> yPosition = new ArrayList<Double>();

		for (int i = 0; i < list.size(); i++) {
			// Uses constant characters in the code to find the X and Y values
			int index1 = list.get(i).indexOf('X');
			int index2 = list.get(i).indexOf('Y');
			int index3 = list.get(i).indexOf('F');
			xPosition.add(Double.parseDouble(list.get(i).substring(index1 + 1, index2 - 2))); // Creating X value
			yPosition.add(Double.parseDouble(list.get(i).substring(index2 + 1, index3 - 2))); // Creating Y value
		}

		for (int k = 0; k < xPosition.size() - 1; k++) {
			// Adds distance to running total for this specific shape
			distance += distance(xPosition.get(k), xPosition.get(k + 1), yPosition.get(k), yPosition.get(k + 1));
		}

		return distance; // Returns total distance traveled for this specific shape
	}

}
